//Taylor Heatherly
//Program 5


package program5;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class RadioButton extends JFrame implements ActionListener
{
	
	private String[] names = {"Bird","Pig","Cat","Dog","Rabbit"};
	private int size=names.length;
	private int[] click = new int[size];	
	private JRadioButton[] buttons;
	private JLabel gif,label;
	private static String title="Radio Button";
	
	public static void main(String[] args){
		RadioButton buttontest=new RadioButton();
	}
	public JLabel getImage(){
		return gif;
	}
	public JLabel getLabel(){
		return label;
	}
	public JRadioButton getRadioButtonAt(int index){
		return buttons[index];
	}
	
	public void actionPerformed(ActionEvent action){  
		gif.setIcon(new ImageIcon("program5/"+action.getActionCommand()+".gif"));
		for(int i=0;i<size;i++){
			if(names[i].equals(action.getActionCommand())){
				click[i]++;
				label.setText(action.getActionCommand()+" button  clicked "+click[i]);
			}
		}
	}

	public RadioButton(){
		super(title);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		

		JPanel totalpanel = new JPanel(new FlowLayout());
		JPanel gifPanel = new JPanel();
		JPanel buttonPanel = new JPanel(new GridLayout(5,1));
		JPanel dataPanel = new JPanel();
		gif=new JLabel(new ImageIcon("./program5/" + names[0] + ".gif",names[0]), JLabel.CENTER);
		label=new JLabel();		
		ButtonGroup bg=new ButtonGroup();
		buttons=new JRadioButton[size];		
		
		add(totalpanel);
		totalpanel.add(gifPanel);
		totalpanel.add(buttonPanel);
		totalpanel.add(dataPanel);		
		gifPanel.add(gif);		
		dataPanel.add(label); 
		
		for(int i=0;i<size;i++){
			buttons[i]=new JRadioButton(names[i]);
			buttons[i].setActionCommand(names[i]);
			buttons[i].addActionListener(this);
			buttonPanel.add(buttons[i]);
			bg.add(buttons[i]);
		}
		buttons[0].setSelected(true);		
		
		this.setSize(450,200);
		setVisible(true);
	}
	
}
