//Taylor Heatherly
//Program 5


package program5;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.Arrays;


public class Calculator extends JFrame implements ActionListener {
	private String[] buttons = {"0", "1", "2", "+", "C",
			"3", "4", "5", "-","(",
			"6", "7", "8", "*",")",
			"9", "+/-", ".", "/","="};
	private JTextField display = new JTextField(20); 
	private int operators=0;
	private boolean parenth=false;
	private double numbers[]={0,0};
	private JButton[] button = new JButton[buttons.length];
	private static String title="Calculator";
	private boolean empty=false;
	private boolean value2=false;
	
	public Calculator(){
		super(title);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		JPanel master = new JPanel();
		this.setSize(500,300);
		
		master.setLayout(new BoxLayout(master, BoxLayout.Y_AXIS));
		JPanel calc =new JPanel(new GridLayout(4,5));
		JPanel output = new JPanel(new FlowLayout());
		add(master);
		output.add(display);
		master.add(output);
		master.add(calc);
		
		for(int i = 0; i < 20; i++) {
			button[i] = new JButton();
			button[i].setText(buttons[i]);
			button[i].setActionCommand(buttons[i]);
			button[i].addActionListener(this);
			calc.add(button[i]);
		}

		display.setEditable(false);
		setVisible(true);
	}

	
	public void getParResult() {
		double result = 0;
		switch(operators){
		case 1:{
			result=numbers[0]+numbers[1];
			break;
		}
		case 2:{
			result=numbers[0]-numbers[1];
			break;
		}
		case 3:{
			result=numbers[0]*numbers[1];
			break;
		}
		case 4:{
			result=numbers[0]/numbers[1];
			break;
		}		
		}
		numbers[0]=result;
	}
	public void getResult() {
		double result = 0;
		numbers[1] = Double.parseDouble(display.getText());
		String numbers0 = Double.toString(numbers[0]);
		String numbers1 = Double.toString(numbers[1]);
		if(numbers0.contains("-")) {
			String[] numbers00 = numbers0.split("-", 2);
			numbers[0] = (Double.parseDouble(numbers00[1]) * -1);
		}
		if(numbers1.contains("-")) {
			String[] numbers11 = numbers1.split("-", 2);
			numbers[1] = (Double.parseDouble(numbers11[1]) * -1);
		}
		switch(operators){
		case 1:{
			result=numbers[0]+numbers[1];
			break;
		}
		case 2:{
			result=numbers[0]-numbers[1];
			break;
		}
		case 3:{
			result=numbers[0]*numbers[1];
			break;
		}
		case 4:{
			result=numbers[0]/numbers[1];
			break;
		}		
		}
		numbers[0]=result;
		display.setText(Double.toString(result));
	}
	public void actionPerformed(ActionEvent ae){
		int num;
		if(operators!=0 && value2==true){
			display.setText("");
			value2=false;
		}
		if(ae.getSource() == button[0]){
			if(empty==true){
				display.setText("");
				empty=false;
			}

			num=0;
			display.setText(display.getText() + num);
		}
		if(ae.getSource() == button[1]){
			if(empty==true){
				display.setText("");
				empty=false;
			}
			num=1;
			display.setText(display.getText() + num);
		}
		if(ae.getSource() == button[2]){
			if(empty==true){
				display.setText("");
				empty=false;
			}
			num=2;
			display.setText(display.getText() + num);
		}
		if(ae.getSource() == button[3]){
			if(parenth==false){
				value2=true;
				if(numbers[0]!=0){
					numbers[1] = Double.parseDouble(display.getText());
					getResult();

				}
				else{
					numbers[0] = Double.parseDouble(display.getText());					
				}
				operators=1;
			}
			else{
				display.setText(display.getText() + "+");
			}
		}
		if(ae.getSource() == button[4]){
			display.setText("");
			operators=0;
			Arrays.fill(numbers,0);
			parenth=false;
			value2=false;
		}
		if(ae.getSource() == button[5]){
			if(empty==true){
				display.setText("");
				empty=false;
			}
			num=3;
			display.setText(display.getText() + num);
		}
		if(ae.getSource() == button[6]){
			if(empty==true){
				display.setText("");
				empty=false;
			}
			num=4;
			display.setText(display.getText() + num);
		}
		if(ae.getSource() == button[7]){
			if(empty==true){
				display.setText("");
				empty=false;
			}
			num=5;
			display.setText(display.getText() + num);
		}
		if(ae.getSource() == button[8]){
			if(parenth==false){
				value2=true;
				if(numbers[0]!=0){
					numbers[1] = Double.parseDouble(display.getText());
					getResult();

				}
				else{
					numbers[0] = Double.parseDouble(display.getText());					
				}
				operators=2;

			}
			else{
				display.setText(display.getText() + "-");
			}
		}
		if(ae.getSource() == button[9]){
			if(parenth==false){
				empty=false;
				parenth=true;
				display.setText("");
				Arrays.fill(numbers,0);
				operators=0;
			}			
			display.setText(display.getText() + "(");

		}
		if(ae.getSource() == button[10]){
			if(empty==true){
				display.setText("");
				empty=false;
			}
			num=6;
			display.setText(display.getText() + num);
		}
		if(ae.getSource() == button[11]){
			if(empty==true){
				display.setText("");
				empty=false;
			}
			num=7;
			display.setText(display.getText() + num);
		}
		if(ae.getSource() == button[12]){
			if(empty==true){
				display.setText("");
				empty=false;
			}
			num=8;
			display.setText(display.getText() + num);
		}
		if(ae.getSource() == button[13]){
			if(parenth==false){				
				value2=true;
				if(numbers[0]!=0){
					numbers[1] = Double.parseDouble(display.getText());
					getResult();

				}
				else{
					numbers[0] = Double.parseDouble(display.getText());					
				}
				operators=3;

			}
			else{
				display.setText(display.getText() + "*");
			}
		}
		if(ae.getSource() == button[14]){
			display.setText(display.getText() + ")");
		}
		if(ae.getSource() == button[15]){
			if(empty==true){
				display.setText("");
				empty=false;
			}
			num=9;
			display.setText(display.getText() + num);
		}
		if(ae.getSource() == button[16]){
			double value = Double.parseDouble(display.getText());
			if(value != 0){
				value = value*(-1);
				display.setText(Double.toString(value));
			}
		}
		if(ae.getSource() == button[17]){
			display.setText(display.getText() + ".");
		}
		if(ae.getSource() == button[18]){
			if(parenth==false){
				value2=true;
				if(numbers[0]!=0){
					numbers[1] = Double.parseDouble(display.getText());
					getResult();
					empty=false;

				}
				else{
					numbers[0] = Double.parseDouble(display.getText());
				}
				operators=4;
			}
			else{
				display.setText(display.getText() + "/");
			}
		}
		if(ae.getSource() == button[19]){
			if(parenth==true){
				String[] arr=display.getText().split("");
				parse(arr);
				empty=true;
				parenth=false;
			}
			else if(parenth==false && numbers[0]!=0){
				getResult();
				numbers[0]=0;
				empty=true;
			}			
		}
	}
	public void parse(String[] equation){
		double x=0;
		double y=0;

		for(int i=2; i<equation.length;i++)	{
			switch(equation[i]){
			case "+":
				operators=1;
				break;
			case "-":
				operators=2;
				break;
			case "*":
				operators=3;
				break;
			case "/":
				operators=4;
				break;
			case "(":
				break;
			case ")":
				break;
			case ".":
				break;
			case "":
				break;
			default:{
				int k=i;
				int count=0;
				StringBuilder temp0 = new StringBuilder();
				while((k+count<equation.length) && !equation[k+count].equals("(") && !equation[k+count].equals(")") && !equation[k+count].equals("+") && !equation[k+count].equals("-") && !equation[k+count].equals("*") && !equation[k+count].equals("/")){
					temp0.append(equation[k+count]);				
					count++;
				}

				String temp1=temp0.toString();				
				i+=count-1;

				if(x==0){
					x=Double.parseDouble(temp1);
					break;
				}

				else{
					y=Double.parseDouble(temp1);
					numbers[0]=x;
					numbers[1]=y;
					getParResult();
					x=numbers[0];
					y=0;
					break;
				}				
			}
			}
		}
		display.setText(Double.toString(numbers[0]));
	}
	
	public JButton getButton(String label){
		int k=0;
		for(int i=0; i<20; i++){
			if(buttons[i].equals(label)){
				k=i;
			}
		}
		return button[k];
	}
	
	public JTextField getJTextField(){
		return(display);
	}
	public static void main(String[] arguments){
		Calculator calc = new Calculator();
	}

}
